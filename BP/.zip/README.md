# Do-not-walk
Addon that make travling faster

## Vanila Item change
### compass
* __Right click__: to go to world 
spawn (click twice in the first time)

### Recouvory compass
* __Right click__: to teleport you to place that you die in last time 

## New Items
### Recall Scroll
* __Shift Right click__: saves position where you are as home
* __Right click__: to go to spawn point or home you select with shift right click

### Scroll of Pain
* __Right click__: to to The Nether

### The end Scroll
__Right click__: to go to The end dimention

### Dimentional Phone
* Combanation with **Recall Scroll**, **Scroll of Pain**, **The end scroll** and compass
* __Right click__: to open the menu and select option
if want to set home:
Shift Right click and select option that has Recall scroll logo

enjoy :D

